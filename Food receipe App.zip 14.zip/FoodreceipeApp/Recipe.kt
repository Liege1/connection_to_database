package com.example.recipeapp.model

data class Recipe(
    val title: String,
    val mealType: String,
    val serves: Int,
    val difficultyLevel: String,
    val ingredients: List<String>,
    val preparationSteps: List<String>
)
class RecipeRepository(private val databaseHelper: RecipeDatabaseHelper) {

    fun insertRecipe(recipe: Recipe) {
        val db = databaseHelper.writableDatabase
        db.insert("recipes", null, recipe.toContentValues())
        db.close()
    }
}
class RecipeRepository(private val databaseHelper: RecipeDatabaseHelper) {

    fun getAllRecipes(): List<Recipe> {
        val db = databaseHelper.readableDatabase
        val cursor = db.query("recipes", null, null, null, null, null, null)
        val recipes = mutableListOf<Recipe>()

        while (cursor.moveToNext()) {
            val id = cursor.getLong(cursor.getColumnIndex("_id"))
            val name = cursor.getString(cursor.getColumnIndex("name"))
            val ingredients = cursor.getString(cursor.getColumnIndex("ingredients"))
            val instructions = cursor.getString(cursor.getColumnIndex("instructions"))

            val recipe = Recipe(id, name, ingredients, instructions)
            recipes.add(recipe)
        }

        cursor.close()
        db.close()

        return recipes
    }
}
