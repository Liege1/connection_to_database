import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class RecipeDatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "recipe.db"
        private const val DATABASE_VERSION = 1
    }


}
override fun onCreate(db: SQLiteDatabase) {
    // Create the tables here
    val createTableQuery = "CREATE TABLE recipes (_id INTEGER PRIMARY KEY, name TEXT, ingredients TEXT, instructions TEXT)"
    db.execSQL(createTableQuery)
}

override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {

    db.execSQL("DROP TABLE IF EXISTS recipes")
    onCreate(db)
}
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class RecipeDatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "recipe.db"
        private const val DATABASE_VERSION = 1
    }

    override fun onCreate(db: SQLiteDatabase) {
        // Create the tables here
        val createTableQuery = "CREATE TABLE recipes (_id INTEGER PRIMARY KEY, name TEXT, ingredients TEXT, instructions TEXT)"
        db.execSQL(createTableQuery)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {

        db.execSQL("DROP TABLE IF EXISTS recipes")
        onCreate(db)
    }
}
class RecipeDatabaseHelper private constructor(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {



    companion object {
        @Volatile
        private var instance: RecipeDatabaseHelper? = null

        fun getInstance(context: Context): RecipeDatabaseHelper {
            return instance ?: synchronized(this) {
                instance ?: RecipeDatabaseHelper(context.applicationContext).also { instance = it }
            }
        }
    }
}
