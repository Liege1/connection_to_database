package com.foodrecipeapp

class `explore page` {
}