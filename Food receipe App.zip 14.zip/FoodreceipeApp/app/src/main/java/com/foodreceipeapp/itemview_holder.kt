package com.foodreceipeapp

class itemview_holder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    // Declare the views you want to reference in the item layout
    val textViewTitle: TextView = itemView.findViewById(R.id.textViewTitle)
    val imageViewPhoto: ImageView = itemView.findViewById(R.id.imageViewPhoto)
}